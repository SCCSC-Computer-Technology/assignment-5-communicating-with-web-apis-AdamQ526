using AdamQuinn_CPT_206_Lab5.Models;
using Microsoft.AspNetCore.Mvc;
using Packt.Shared;
using System.Diagnostics;
using TheFirstWebAPI.Repositories;

namespace AdamQuinn_CPT_206_Lab5.Controllers
{
    public class HomeController : Controller
    {

        private readonly IHttpClientFactory client;
        private readonly ILogger<HomeController> _logger;
        private ICustomerRepository data;

        public HomeController(ILogger<HomeController> logger, ICustomerRepository context, IHttpClientFactory factory)
        {
            _logger = logger;
            data = context;
            client = factory;
        }

        public async Task<IActionResult> Customers(string country)
        {
            string uri;

            if (string.IsNullOrEmpty(country))
            {
                ViewData["Title"] = "All Records Shown";
                uri = "api/Customer/";
            }
            else
            {
                ViewData["Title"] = $"records Where country = {country}";
                uri = $"api/Customer/?country = {country}";
            }

            HttpClient client2 = client.CreateClient(name: "TheFirstWebAPI");

            HttpRequestMessage request = new(method: HttpMethod.Get, requestUri: uri);

            HttpResponseMessage response = await client2.SendAsync(request);

            IEnumerable<Customer>? model = await response.Content.ReadFromJsonAsync<IEnumerable<Customer>>();

            return View(model);
        }
        public IActionResult Index()
        {
            return View();
        }

        public IActionResult Privacy()
        {
            return View();
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
    }
}
